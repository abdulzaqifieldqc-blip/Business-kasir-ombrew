# OMBREW Kasir TABLET — paket siap jadi APK

Aplikasi kasir offline OMBREW Coffee & Beverage, dibungkus dengan Capacitor 7.
Isi aplikasi ada di `www/index.html` (gambar menu di `www/img/`).

## Cara paling mudah — tanpa install apa pun (GitHub)
1. Buat repository baru di github.com, unggah **semua isi folder zip ini** (termasuk folder `.github`).
2. Buka tab **Actions** → **Build APK OMBREW** → **Run workflow**.
3. Tunggu ±5–8 menit, unduh **OMBREW-Tablet-apk** dari bagian *Artifacts*, ekstrak, lalu pasang `OMBREW-Tablet.apk` di HP.

## Build di komputer sendiri
Syarat: Node.js 20+, JDK 21, Android SDK (variabel `ANDROID_HOME`).
- Windows: jalankan `build-apk.bat`
- Linux/macOS: jalankan `bash build-apk.sh`

Hasil: `OMBREW-Tablet.apk` di folder ini.

## Via Android Studio
```
npm install
npx cap add android
npx @capacitor/assets generate --android --assetPath assets
npx cap sync android
npx cap open android
```
Lalu Build → Build APK(s).

## Catatan
- APK yang dihasilkan berjenis **debug** (bertanda tangan kunci debug), bisa langsung dipasang di HP (aktifkan "pasang dari sumber tidak dikenal").
  Untuk rilis Play Store, buat Signed Bundle/APK di Android Studio.
- Nama paket: `com.ombrew.kasir.tablet` (ubah di `capacitor.config.json` sebelum build pertama bila perlu).
- Data (menu, transaksi, stok, keuangan) tersimpan di penyimpanan lokal aplikasi. Mencopot aplikasi / "Hapus data" akan menghapusnya.
- Ubah isi aplikasi: edit `www/index.html`, lalu build ulang.

- Versi tablet: navigasi di sisi kiri, keranjang permanen di sisi kanan, panel tampil sebagai dialog tengah. Orientasi layar bebas (portrait/landscape). ID paket berbeda dari versi HP, jadi keduanya bisa dipasang berdampingan (data tidak dibagi).
