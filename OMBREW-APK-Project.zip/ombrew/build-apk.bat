@echo off
REM Build APK OMBREW (Windows). Syarat: Node.js 20+, JDK 21, Android SDK (ANDROID_HOME).
cd /d "%~dp0"
call npm install || goto :err
if not exist android call npx cap add android || goto :err
call npx @capacitor/assets generate --android --assetPath assets || goto :err
powershell -NoProfile -Command "$p='android/app/src/main/AndroidManifest.xml'; $t=Get-Content $p -Raw; if($t -notmatch 'screenOrientation'){ $t=$t -replace '<activity ','<activity android:screenOrientation=\"portrait\" '; Set-Content $p $t }"
call npx cap sync android || goto :err
cd android
call gradlew.bat assembleDebug || goto :err
cd ..
copy /Y android\app\build\outputs\apk\debug\app-debug.apk OMBREW.apk
echo SELESAI: OMBREW.apk
goto :eof
:err
echo GAGAL - lihat pesan error di atas
exit /b 1
