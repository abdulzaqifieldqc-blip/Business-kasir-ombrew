# OMBREW Kasir — paket siap jadi APK

Aplikasi kasir OMBREW Coffee & Beverage (offline-first, dengan sinkron online), dibungkus dengan Capacitor 7.
Isi aplikasi ada di `www/index.html` (gambar menu di `www/img/`).

## Cara paling mudah — tanpa install apa pun (GitHub)
1. Buat repository baru di github.com, unggah **semua isi folder zip ini** (termasuk folder `.github`).
2. Buka tab **Actions** → **Build APK OMBREW** → **Run workflow**.
3. Tunggu ±5–8 menit, unduh **OMBREW-apk** dari bagian *Artifacts*, ekstrak, lalu pasang `OMBREW.apk` di HP.

## Build di komputer sendiri
Syarat: Node.js 20+, JDK 21, Android SDK (variabel `ANDROID_HOME`).
- Windows: jalankan `build-apk.bat`
- Linux/macOS: jalankan `bash build-apk.sh`

Hasil: `OMBREW.apk` di folder ini.

## Via Android Studio
```
npm install
npx cap add android
npx @capacitor/assets generate --android --assetPath assets
npx cap sync android
npx cap open android
```
Lalu Build → Build APK(s).

## Sistem online (Supabase)
- Server: proyek Supabase `ombrew-kasir` (tabel `ombrew_*`, akses hanya lewat fungsi server yang dikunci **kode outlet**).
- Di aplikasi: ikon awan di header, atau **Kelola › Sistem Online**. HP pertama membuat kode outlet (min. 6 karakter); HP lain memasukkan kode yang sama.
- Data (transaksi, keuangan, menu, bahan baku, resep) dikirim otomatis saat ada internet. Tanpa internet aplikasi tetap jalan dan data menyusul.
- Konflik: data yang paling baru diubah yang dipakai. Stok bahan baku disinkronkan sebagai satu data; bila dua HP berjualan bersamaan saat offline, stok bisa selisih — cek ulang lewat Bahan Baku.
- Menghubungkan HP yang sudah punya data ke outlet yang sudah berisi: isi server yang dipakai untuk menu, bahan baku, dan resep.

## Fitur keuangan
- **Modal kembalian**: Kelola › Uang Masuk & Keluar › *Tambah Modal Kembalian*. Menambah Kas Cash di laci, bukan penjualan.
- **Kas Cash (laci)** = modal + penjualan cash + uang masuk cash − uang keluar cash. **Saldo Online** = QRIS + masuk online − keluar online.
- Setiap uang masuk/keluar mencatat **dari mana / ke mana** dan **metode Cash atau Online**.
- **Rekap penjualan** (tab Transaksi) dan **laporan** bisa dipilih per tanggal.
- Tombol ✕ di bawah panel Transaksi dan Kelola untuk menutup.

## Catatan
- APK yang dihasilkan berjenis **debug** (bertanda tangan kunci debug), bisa langsung dipasang di HP (aktifkan "pasang dari sumber tidak dikenal").
  Untuk rilis Play Store, buat Signed Bundle/APK di Android Studio.
- Nama paket: `com.ombrew.kasir` (ubah di `capacitor.config.json` sebelum build pertama bila perlu).
- Data (menu, transaksi, stok, keuangan) tersimpan di penyimpanan lokal aplikasi. Mencopot aplikasi / "Hapus data" akan menghapusnya.
- Ubah isi aplikasi: edit `www/index.html`, lalu build ulang.
