#!/usr/bin/env bash
# Build APK OMBREW (Linux / macOS / Git Bash).
# Syarat: Node.js 20+, JDK 21, Android SDK (ANDROID_HOME terisi). Butuh internet saat pertama kali.
set -euo pipefail
cd "$(dirname "$0")"

npm install
[ -d android ] || npx cap add android
npx @capacitor/assets generate --android --assetPath assets

# Kunci layar portrait
MANIFEST=android/app/src/main/AndroidManifest.xml
grep -q 'screenOrientation' "$MANIFEST" || sed -i.bak 's/<activity /<activity android:screenOrientation="portrait" /' "$MANIFEST"

npx cap sync android
( cd android && ./gradlew assembleDebug )

cp android/app/build/outputs/apk/debug/app-debug.apk ./OMBREW.apk
echo "SELESAI -> $(pwd)/OMBREW.apk"
