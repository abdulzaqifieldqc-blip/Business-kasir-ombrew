#!/usr/bin/env bash
# Build APK OMBREW (Linux / macOS / Git Bash).
# Syarat: Node.js 20+, JDK 21, Android SDK (ANDROID_HOME terisi). Butuh internet saat pertama kali.
set -euo pipefail
cd "$(dirname "$0")"

npm install
[ -d android ] || npx cap add android
npx @capacitor/assets generate --android --assetPath assets

# Tablet: orientasi bebas (portrait & landscape)

npx cap sync android
( cd android && ./gradlew assembleDebug )

cp android/app/build/outputs/apk/debug/app-debug.apk ./OMBREW-Tablet.apk
echo "SELESAI -> $(pwd)/OMBREW-Tablet.apk"
